import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='raulledo',
    application_name='api-rest',
    app_uid='dchkr1fJ7msshLv9XW',
    org_uid='59695950-0852-4c73-99aa-5b0f067e1ad3',
    deployment_uid='f9fd88f3-37a8-4386-88d1-83ce3c136d59',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-update', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/update.update')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
